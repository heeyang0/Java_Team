package HotelSys;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.mysql.cj.xdevapi.AddResultBuilder;

import HotelSys.item.JRoundButton;

import java.util.Random;
import java.awt.SystemColor;

public class NoCard extends JFrame {

	private String selectedBank;
	private JPanel contentPane;
	private final JPanel panel = new JPanel();
	private String id;
	private String name;
	private String phone_num;
	private String point;
	private String cKi;
	private String cKo;
	private long difference;

//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					noCard frame = new noCard("은행사");
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	public NoCard(String selectedBank, String id, String name, String phone_num, String point, String cKi, String cKo,
			long difference) {
		this.selectedBank = selectedBank;
		this.id = id;
		this.name = name;
		this.phone_num = phone_num;
		this.point = point;
		this.cKi = cKi;
		this.cKo = cKo;
		this.difference = difference; // 예약한 기간 차이

		setTitle("무통장 입금창");
		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);
		JLabel imageLabel = new JLabel();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 494);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		this.selectedBank = selectedBank;
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(this);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 436, 491);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("예약완료");
		lblNewLabel.setBounds(162, 54, 124, 28);
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 26));
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("아래 가상계좌로 입금해주시면 정상적으로");
		lblNewLabel_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(104, 92, 251, 49);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("결제완료 처리됩니다.");
		lblNewLabel_1_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 13));
		lblNewLabel_1_1.setBounds(162, 118, 137, 49);
		panel.add(lblNewLabel_1_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("images/check.png"));
		lblNewLabel_2.setBounds(196, 10, 54, 34);
		panel.add(lblNewLabel_2);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(12, 175, 412, 279);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_3 = new JLabel("가상계좌정보");
		lblNewLabel_3.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(12, 0, 125, 41);
		panel_1.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("계좌정보");
		lblNewLabel_4.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(12, 40, 114, 21);
		panel_1.add(lblNewLabel_4);

		JLabel bankname = new JLabel(selectedBank + " : " + generateRandomNumber());
		bankname.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		bankname.setBounds(48, 71, 200, 33);
		panel_1.add(bankname);

		JLabel bankname_1 = new JLabel("예금주 : 엄청나호텔");
		bankname_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		bankname_1.setBounds(48, 103, 200, 33);
		panel_1.add(bankname_1);

		JLabel lblNewLabel_4_1 = new JLabel("결제금액");
		lblNewLabel_4_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 18));
		lblNewLabel_4_1.setBounds(12, 146, 114, 21);
		panel_1.add(lblNewLabel_4_1);

		JLabel bankname_1_1 = new JLabel("금액");
		bankname_1_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		// 여기에 금액
		if (point == "싱글룸") {
			bankname_1_1.setText("금액: " + difference * 70000 + "");
		}
		if (point == "더블룸") {
			bankname_1_1.setText("금액: " + difference * 100000 + "");
		}
		if (point == "트윈룸") {
			bankname_1_1.setText("금액: " + difference * 100000 + "");
		}
		if (point == "스위트룸") {
			bankname_1_1.setText("금액: " + difference * 200000 + "");
		}

		bankname_1_1.setBounds(48, 175, 200, 33);
		panel_1.add(bankname_1_1);

		JLabel bankname_2 = new JLabel("예약 후 3일 이내에 입금하지 않으면 주문이 자동 취소됩니다.");
		bankname_2.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 13));
		bankname_2.setBounds(48, 202, 364, 33);
		panel_1.add(bankname_2);

		JRoundButton btnNewButton = new JRoundButton("확인");
		btnNewButton.setBackground(new Color(157, 254, 143));
		btnNewButton.setForeground(new Color(100, 100, 100));
		btnNewButton.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 16));
		btnNewButton.setBounds(12, 235, 390, 33);
		panel_1.add(btnNewButton);
		
		
		btnNewButton.addActionListener(new ActionListener() {
			private String colslangth;

			public void actionPerformed(ActionEvent e) {

				System.out.println("버튼눌림");
				try {
					DB.init();
					String length = "SELECT COUNT(순번) FROM hotel";
					ResultSet rs = DB.getResultSet(length);
					if (rs.next()) {
						int cols = rs.getInt(1);
						colslangth = String.valueOf(cols + 1);
					}

					System.out.println(id + "\t" + "name" + "\t" + "phone_num" + "\t" + point + "\t" + cKi + "\t" + cKo
							+ "\t" + colslangth);

					String sql = "INSERT INTO hotel (아이디, 이름, 전화번호, 방번호, 체크인, 체크아웃) VALUES (?, ?, ?, ?, ?, ?)";
					DB.executeUpdate(sql, id, name, phone_num, point, cKi, cKo);
					DB.commit(); // DB 변경 사항을 커밋
					DB.close(); // DB 커넥션을 닫습니다.

					JOptionPane.showMessageDialog(null, "예약이 완료되었습니다.");
					//System.exit(0); //강제 종료
					setVisible(false);
					int answer = JOptionPane.showConfirmDialog(null, "홈으로 돌아가시겠습니까?", "confirm",JOptionPane.YES_NO_OPTION );
					if(answer == JOptionPane.YES_OPTION){
						//사용자가 yes를 눌렀을 떄
						new SelectWindow(id);
					} else{
						//사용자가 NO 외 값 입력시
						JOptionPane.showMessageDialog(null, "로그아웃후 프로그램이 종료 됩니다.");
						System.exit(0); //시스템 강제종료
					}

				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

				setVisible(false);
			}
		});
		setVisible(true);
	}

	public String getSelectedBank() {
		return selectedBank;
	}

	private String generateRandomNumber() { // 13자리 랜덤 숫자 생성
		Random random = new Random();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 13; i++) {
			int digit = random.nextInt(10);
			sb.append(digit);
		}
		return sb.toString();
	}

	
}
