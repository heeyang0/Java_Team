package HotelSys;

public class Main { // 메인으로 실행하는 부분이다.
	public static void main(String[] args) {
		new Login("로그인창");
	}
}