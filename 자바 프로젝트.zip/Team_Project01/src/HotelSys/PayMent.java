package HotelSys;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import HotelSys.item.JRoundButton;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.util.function.ToDoubleBiFunction;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class PayMent extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textField_1;
	private JPanel panel_3;
	public JComboBox<String> bank;
	private String id = "";
	private String name = "";
	private String phone_num = "";
	private String point = "";
	private String cKi = "";
	private String cKo = "";
	private long difference = 0;
	private JRadioButton card;
	private JRadioButton nocard;
	private JTextField textField;
	private JRoundButton btnNewButton_1;

	public JComboBox<String> getBankComboBox() {
		return bank;

	}

	public PayMent(String id, String name, String phone_num, String point, String cKi, String cKo, long difference) {
		this.id = id;
		this.name = name;
		this.phone_num = phone_num;
		this.point = point;
		this.cKi = cKi;
		this.cKo = cKo;
		this.difference = difference; // 예약한 기간 차이

		setTitle("결제창");
		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);
		JLabel imageLabel = new JLabel();
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 432, 500);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 416, 461);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("-----------결제수단-----------");
		lblNewLabel.setBounds(95, 10, 255, 33);
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 22));
		panel.add(lblNewLabel);
		Border border = BorderFactory.createLineBorder(Color.gray, 1);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(12, 75, 388, 34);
		panel.add(panel_1);
		panel_1.setBorder(border);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));
		card = new JRadioButton("신용/체크카드");
		card.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 14));
		card.setFocusPainted(false);
		card.addActionListener(this);
		panel_1.add(card);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(12, 107, 388, 34);
		panel.add(panel_2);
		panel_2.setBorder(border);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.Y_AXIS));
		nocard = new JRadioButton("무통장입금(가상계좌)");
		nocard.addActionListener(this);
		nocard.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 14));
		nocard.addActionListener(this);

		panel_2.add(nocard);
		ButtonGroup paymentGroup = new ButtonGroup();
		paymentGroup.add(card);
		paymentGroup.add(nocard);

		panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(12, 161, 388, 215);
		panel.add(panel_3);
		panel_3.setLayout(null);
		panel_3.setVisible(false);
		String[] items = { "KB 국민", "신한", "현대", "삼성", "농협", "우리", "하나은행", "비씨", "롯데" };

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("images/down.png"));
		lblNewLabel_1.setBounds(174, 10, 34, 39);
		panel_3.add(lblNewLabel_1);

		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(255, 255, 255));
		panel_4.setBounds(0, 59, 388, 155);
		panel_4.setBorder(border);
		panel_3.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("은행 선택 ");
		lblNewLabel_2.setBounds(33, 31, 110, 26);
		panel_4.add(lblNewLabel_2);
		lblNewLabel_2.setFont(new Font("휴먼모음T", Font.PLAIN, 16));

		JLabel lblNewLabel_2_1 = new JLabel("입금자명");
		lblNewLabel_2_1.setBounds(33, 83, 110, 26);
		panel_4.add(lblNewLabel_2_1);
		lblNewLabel_2_1.setFont(new Font("휴먼모음T", Font.PLAIN, 16));
		bank = new JComboBox<>(new DefaultComboBoxModel<>(items));
		bank.setBackground(new Color(255, 255, 255));
		bank.setBounds(133, 34, 110, 23);

		panel_4.add(bank);

		textField = new JTextField();
		textField.setBounds(133, 87, 110, 21);
		panel_4.add(textField);

		textField.setColumns(10);

		btnNewButton_1 = new JRoundButton("\uD655\uC778");
		btnNewButton_1.setBounds(25, 396, 368, 42);
		panel.add(btnNewButton_1);
		btnNewButton_1.setForeground(new Color(77, 77, 77));
		btnNewButton_1.setFont(new Font("휴먼모음T", Font.PLAIN, 17));
		btnNewButton_1.setBackground(new Color(157, 254, 143));
		btnNewButton_1.setVisible(false);
		btnNewButton_1.addActionListener(this);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		String selectedBank = (String) bank.getSelectedItem();

		if (obj == card) {
			panel_3.setVisible(false);
			btnNewButton_1.setVisible(true);

		} else if (obj == nocard) {
			panel_3.setVisible(true);
			btnNewButton_1.setVisible(true);
		}
		if (obj == btnNewButton_1) {
			if (card.isSelected() == true) {
				// 카드결제창
				setVisible(false);
				new CardPay(id, name, phone_num, point, cKi, cKo, difference);

			} else if (nocard.isSelected() == true) {
				setVisible(false);
				new NoCard(selectedBank, id, name, phone_num, point, cKi, cKo, difference);
			}
		}
	}

}
