package HotelSys.item;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;

import javax.swing.*;
import javax.swing.border.Border;

public class RoundedJTextField extends JTextField {

	private Shape shape;
	private Border border = BorderFactory.createEmptyBorder(0, 5, 0, 5);

	public RoundedJTextField(int size) {
		super(size);
		setOpaque(false);
	}

	@Override
	protected void paintComponent(Graphics g) {
		g.setColor(getBackground());
		g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10); // 맨 뒤에 10,10 써있는걸로 둥근거 조절
		super.paintComponent(g);
	}

	@Override
	protected void paintBorder(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setColor(getForeground());
		g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);// 맨 뒤에 10,10 써있는걸로 둥근거 조절
	}

	@Override
	public boolean contains(int x, int y) {
		if (shape == null || !shape.getBounds().equals(getBounds())) {
			shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
		}
		return shape.contains(x, y);
	}

	public void setBorder(Border border) {
		this.border = border;
	}

	public Border getBorder() {
		return this.border;
	}
}