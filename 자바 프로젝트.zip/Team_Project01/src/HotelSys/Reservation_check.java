package HotelSys;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;

import HotelSys.item.JRoundButton;

import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

public class Reservation_check extends JFrame implements ActionListener {

	private JPanel contentPane;
	private String id;
	private JTable table;
	private JRoundButton btnNewButton;
	private JTextField textField;
	private JLabel lblNewLabel;
	private JRoundButton btnNewButton_1;
	private Connection connection;
	private PreparedStatement statement;
	private JRoundButton btnNewButton_2;
	
	

	public Reservation_check(String id) {
		this.id = id;
		connectToDatabase(); // 데이터베이스 연결
		initialize();
		// 테이블 모델 생성 및 컬럼 이름 지정
		DefaultTableModel tableModel = new DefaultTableModel(
				new Object[] { "아이디", "이름", "전화번호", "방번호", "체크인", "체크아웃", "순번" }, 0);
		table.setModel(tableModel);

		JLabel lblNewLabel_1 = new JLabel("ID: " + id);
		lblNewLabel_1.setForeground(new Color(167, 167, 167));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(12, 5, 129, 15);
		contentPane.add(lblNewLabel_1);
		
		
	}

	private void initialize() {
		setTitle("개인조회");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 711, 337);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(219, 236, 230));
		contentPane.setLayout(null);

		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(153, 52, 530, 236);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		Toolkit kit = Toolkit.getDefaultToolkit(); // icon
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		btnNewButton = new JRoundButton("");
		btnNewButton.setText("예약취소");
		btnNewButton.setBackground(new Color(219, 236, 255));
		btnNewButton.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(12, 108, 97, 49);
		contentPane.add(btnNewButton);
		setLocationRelativeTo(null);
		
		btnNewButton_2 = new JRoundButton("");
		btnNewButton_2.setText("뒤로가기");
		btnNewButton_2.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
		btnNewButton_2.setBackground(new Color(219, 236, 255));
		btnNewButton_2.setBounds(12, 239, 97, 49);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(this);
		setVisible(true);

		btnNewButton_1 = new JRoundButton("예약조회");
		btnNewButton_1.setBackground(new Color(219, 236, 255));
		btnNewButton_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBounds(12, 49, 97, 49);
		contentPane.add(btnNewButton_1);

		lblNewLabel = new JLabel("예약조회");
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(153, 10, 87, 32);
		contentPane.add(lblNewLabel);

		setVisible(true);

		// 데이터베이스 연결
		connectToDatabase();
	}

	private void connectToDatabase() {
		try {
			connection = DB.getConnection();
			DB.init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadData() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);

		String sql = "SELECT * FROM hotel WHERE 아이디 = ?";
		try {
			statement = connection.prepareStatement(sql); // PreparedStatement 객체 초기화
			statement.setString(1, id); // 플레이스홀더에 값 설정

			ResultSet rs = statement.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();

			int cols = metaData.getColumnCount();
			String[] colName = new String[cols];

			for (int i = 0; i < colName.length; i++) {
				colName[i] = metaData.getColumnName(i + 1);
			}
			model.setColumnIdentifiers(colName);

			while (rs.next()) {
				Vector<Object> vec = new Vector<>();
				vec.add(rs.getString(1));
				vec.add(rs.getString(2));
				vec.add(rs.getString(3));
				vec.add(rs.getString(4));
				vec.add(rs.getDate(5));
				vec.add(rs.getDate(6));
				vec.add(rs.getInt(7));

				model.addRow(vec);
			}

			rs.close(); // ResultSet을 명시적으로 닫아줍니다.
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("데이터 불러오기 오류");
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == btnNewButton_1) { // 예약조회 버튼 클릭 시
			loadData();

		} else if (obj == btnNewButton) {
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			int[] selectedRows = table.getSelectedRows();
			for (int i = selectedRows.length - 1; i >= 0; i--) {
				int selectedRowIndex = selectedRows[i];
				int idToDelete = (int) model.getValueAt(selectedRowIndex, 6);

				model.removeRow(selectedRowIndex);

				// DB에서 해당 아이디의 데이터 삭제
				deleteDataFromDB(idToDelete);
			}
		}else if(obj == btnNewButton_2) {
			setVisible(false);
			new SelectWindow(id);
		}
	}

	private void deleteDataFromDB(int idToDelete) {
		String sql = "DELETE FROM hotel WHERE 순번 = ?";

		try {
			DB.init();
			DB.executeUpdate(sql, idToDelete + "");
		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			System.out.println("데이터 삭제 오류");
		}
	}
}