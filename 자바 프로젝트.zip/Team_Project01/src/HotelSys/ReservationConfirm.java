package HotelSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import HotelSys.item.JRoundButton;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.SwingConstants;

public class ReservationConfirm extends JFrame implements ItemListener, ActionListener {
	private String cKi;
	private String cKo;
	private ImageIcon roomPic;
	private JPanel contentPane;
	private JRoundButton btnNewButton;
	private String point;
	private String colslangth;
	private long difference;
	private String id;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * 
	 * @param cKo
	 * @param cKi
	 * @param roomPic
	 * @param point
	 */
	public ReservationConfirm(String cKi, String cKo, ImageIcon roomPic, String point, String id, long difference) { // 빼둠
		this.cKi = cKi;
		this.cKo = cKo;
		this.roomPic = roomPic;
		this.point = point;
		this.id = id;
		this.difference = difference;
//		this.cKi = "2023-04-03";
//		this.cKo = "2023-01-02";
//		this.roomPic = new ImageIcon("images/sin.png");
//		this.point = "룸1";
//		this.idi = "aaabb";

		setTitle("\uC608\uC57D\uD655\uC778");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 390, 220);
		setLocationRelativeTo(this);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(181, 218, 225));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 238, 241));
		panel.setBounds(0, 10, 374, 127);
		contentPane.add(panel);
		panel.setLayout(null);
		ImageIcon roomImg = imgchanger(roomPic);

		JLabel lblNewLabel_1 = new JLabel("\uC2F1\uAE00\uB8F8");
		lblNewLabel_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		lblNewLabel_1.setBounds(170, 34, 66, 15);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("1\uC778 \uD22C\uC219 \uAC00\uB2A5\uD55C \uAC1D\uC2E4");
		lblNewLabel_2.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 13));
		lblNewLabel_2.setBounds(170, 49, 148, 15);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\uC635\uC158: \uC2F1\uAE00 \uCE68\uB300(1)");
		lblNewLabel_3.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 11));
		lblNewLabel_3.setBounds(170, 62, 192, 15);
		panel.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\uD22C\uC219 \uAE30\uAC04:");
		lblNewLabel_4.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(170, 74, 57, 15);
		panel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel(cKi + " ~ " + cKo);
		lblNewLabel_5.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 11));
		lblNewLabel_5.setBounds(228, 74, 146, 15);
		panel.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("\uACB0\uC7AC\uAE08\uC561 :");
		lblNewLabel_6.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(170, 88, 66, 29);
		panel.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("￦000,000원");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(240, 88, 122, 29);
		panel.add(lblNewLabel_7);
		JLabel roomLb = new JLabel(roomImg);
		roomLb.setBounds(19, 18, 139, 88);
		panel.add(roomLb);

		JLabel lblNewLabel_8 = new JLabel();
		lblNewLabel_8.setIcon(new ImageIcon("images/icon.png"));
		lblNewLabel_8.setBounds(305, 18, 57, 31);
		panel.add(lblNewLabel_8);

		// 예약하기 버튼
		btnNewButton = new JRoundButton("\uC608\uC57D\uD558\uAE30");
		btnNewButton.setEnabled(false);
		btnNewButton.setBackground(new Color(197, 225, 231));
		btnNewButton.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		btnNewButton.setBounds(272, 141, 102, 35);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(this);

		JLabel lblNewLabel = new JLabel("\uC0C1\uAE30 \uB0B4\uC6A9\uC744 \uD655\uC778\uD558\uC168\uC2B5\uB2C8\uAE4C?");
		lblNewLabel.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 16));
		lblNewLabel.setBounds(22, 147, 216, 25);
		contentPane.add(lblNewLabel);

		// 체크박스
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setBackground(new Color(181, 218, 225));
		chckbxNewCheckBox.setBounds(243, 147, 21, 23);
		chckbxNewCheckBox.addItemListener(this);
		contentPane.add(chckbxNewCheckBox);

		if (point == "싱글룸") {
			lblNewLabel_1.setText("싱글룸");
			lblNewLabel_2.setText("1인 투숙 가능한 객실");
			lblNewLabel_3.setText("옵션: 싱글 침대(1)");
			// 5번은 체크인, 체크아웃 기간 들어가는데 이미 위에서 선언돼있음.
			lblNewLabel_7.setText("￦" + String.valueOf(difference * 70000) + "원");
		} else if (point == "더블룸") {
			lblNewLabel_1.setText("더블룸");
			lblNewLabel_2.setText("2인 투숙 가능한 객실");
			lblNewLabel_3.setText("옵션: 더블 침대(1)");
			lblNewLabel_7.setText("￦" + String.valueOf(difference * 100000) + "원");
		} else if (point == "트윈룸") {
			lblNewLabel_1.setText("트윈룸");
			lblNewLabel_2.setText("2인 투숙 가능한 객실");
			lblNewLabel_3.setText("옵션: 싱글 침대(2)");
			lblNewLabel_7.setText("￦" + String.valueOf(difference * 100000) + "원");
		} else if (point == "스위트룸") {
			lblNewLabel_1.setText("스위트룸");
			lblNewLabel_2.setText("Vip전용 객실");
			lblNewLabel_3.setText("옵션: 문의시 옵션 조정가능");
			lblNewLabel_7.setText("￦" + String.valueOf(difference * 200000) + "원");
		}

		// 보이기
		setVisible(true);
	}

	private ImageIcon imgchanger(ImageIcon changeicon) { // 이미지 비율 맞춰주는거
		Image change = changeicon.getImage(); // 받은 아이콘의 이미지를 추출해서 이미지 타입으로 넣음
		Image change2 = change.getScaledInstance(139, 88, java.awt.Image.SCALE_SMOOTH); // 받은걸 크기 맞춰주고 비율을 자동으로 맞춤
		ImageIcon tt = new ImageIcon(change2); // 맞춘걸 다시 이미지 아이콘으로 변환
		return tt; // 리턴
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED)
			btnNewButton.setEnabled(true);
		else
			btnNewButton.setEnabled(false);

	}

	// 여기서 넘기면 됨
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
//		System.out.println(cKi + cKo + point + id);
//
		// id 매칭해서 이름, 전화번호 값 가져옴
		DB btnsearch = new DB(); // db객체 만듦
		String name = btnsearch.selectjy(id, "이름");
		String phone_num = btnsearch.selectjy(id, "전화번호");
//
//		System.out.println("버튼눌림");
//		try {
//			DB.init();
//			String length = "SELECT COUNT(순번) FROM hotel";
//			ResultSet rs = DB.getResultSet(length);
//			if (rs.next()) {
//				int cols = rs.getInt(1);
//				colslangth = String.valueOf(cols + 1);
//			}
//
////				
//
////
////			
////			    
////			
//			System.out.println(id + "\t" + "name" + "\t" + "phone_num" + "\t" + point + "\t" + cKi + "\t" + cKo + "\t" + colslangth);
//
//			String sql = "INSERT INTO hotel (아이디, 이름, 전화번호, 방번호, 체크인, 체크아웃) VALUES (?, ?, ?, ?, ?, ?)";
//			DB.executeUpdate(sql, id, name, phone_num, point, cKi, cKo);
//			DB.commit(); // DB 변경 사항을 커밋
//			DB.close(); // DB 커넥션을 닫습니다.
//
//			JOptionPane.showMessageDialog(null, "예약이 완료되었습니다.");
//			System.exit(0);
//
//		} catch (ClassNotFoundException e1) {
//			e1.printStackTrace();
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}

		if (obj == btnNewButton) {
			setVisible(false);
			new PayMent(id, name, phone_num, point, cKi, cKo, difference);
		}

	}

}
