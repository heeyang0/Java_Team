package HotelSys;

import java.beans.Statement;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.PreparableStatement;

public class DB {
	private static Connection conn;
	static java.sql.Statement stmt;

	private String id;
	private String it;

	public static void init() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "gowjd0410@@");
		stmt = conn.createStatement();
		conn.setAutoCommit(false);
		System.out.println("DB 접속 완료");
	}

	public static ResultSet getResultSet(String sql) {
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public static int runSQL(String sql) {

		int i = 0;

		try {
			i = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public static void close() {
		try {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void executeUpdate(String sql, String 이름, String 전화번호, String 방번호, String 체크인, String 체크아웃, String 순번,
			String 아이디) throws SQLException {
		PreparedStatement pstmt = conn.prepareStatement(sql);
		// "UPDATE hotel SET 이름 = ?, 전화번호 = ?, 방번호 = ?, 체크인 = ?, 체크아웃 = ?, 순번 = ? WHERE
		// 아이디 = ?";
		pstmt.setString(1, 이름);
		pstmt.setString(2, 전화번호);
		pstmt.setString(3, 방번호);
		pstmt.setString(4, 체크인);
		pstmt.setString(5, 체크아웃);
		pstmt.setString(6, 순번);
		pstmt.setString(7, 아이디);
		pstmt.executeUpdate();
		pstmt.close();
	}

	// 인자 6개짜리(예약확인창)
	public static void executeUpdate(String sql, String 인자1, String 인자2, String 인자3, String 인자4, String 인자5, String 인자6)
			throws SQLException {
		PreparedStatement pstmt = conn.prepareStatement(sql);
		// "INSERT INTO member (이름, 전화번호 이메일, 아이디, 비밀번호) VALUES (?, ?, ?, ?, ?)"
		pstmt.setString(1, 인자1);
		pstmt.setString(2, 인자2);
		pstmt.setString(3, 인자3);
		pstmt.setString(4, 인자4);
		pstmt.setString(5, 인자5);
		pstmt.setString(6, 인자6);
		pstmt.executeUpdate();
		pstmt.close();
	}

	// 인자 5개짜리(회원가입부)
	public static void executeUpdate(String sql, String 인자1, String 인자2, String 인자3, String 인자4, String 인자5)
			throws SQLException {
		PreparedStatement pstmt = conn.prepareStatement(sql);
		// "INSERT INTO member (이름, 전화번호 이메일, 아이디, 비밀번호) VALUES (?, ?, ?, ?, ?)"
		pstmt.setString(1, 인자1);
		pstmt.setString(2, 인자2);
		pstmt.setString(3, 인자3);
		pstmt.setString(4, 인자4);
		pstmt.setString(5, 인자5);
		pstmt.executeUpdate();
		pstmt.close();
	}

	public static void executeUpdate(String sql, String id) throws SQLException {
		conn.setAutoCommit(false);

		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.executeUpdate();
		pstmt.close();

		conn.commit();
		conn.setAutoCommit(true);
	}

	public static void commit() {
		try {

			conn.commit(); // 커밋 수행
			System.out.println("커밋 완료");
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("커밋 오류");
		}
	}

	public static Connection getConnection() {
		// TODO Auto-generated method stub
		return conn;
	}

	// 값 가져오는거에서 씀
	public DB() { // 기본적인 객체 만드는거
	}

	// select기능임 id에 고객 아이디를 넣으면 그 고객의 it 값을 가져옴 -jy
	public String selectjy(String id, String it) {
		this.id = id;
		this.it = it;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String want = null;

		try {
			try {
				DB.init();
				String sql = "SELECT " + it + " FROM member WHERE id = ?";
				stmt = conn.prepareStatement(sql);
				stmt.setString(1, id);
				rs = stmt.executeQuery();

				if (rs.next()) {
					want = rs.getString(1);
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		return want;
	}

}