package HotelSys;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

public class QRcode extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public QRcode(String title) {
		setTitle(title);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 500, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 196, 174));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JLabel lblNewLabel = new JLabel("New label");
		contentPane.add(lblNewLabel);

		ImageIcon swtimg = new ImageIcon("images/QR2.png");
		ImageIcon swtimage = imgchanger(swtimg);

		JLabel swtrm = new JLabel(swtimage);

		getContentPane().add(swtrm);
		
		setVisible(true);
	}

	// 이미지 비율 맞춰주는거
	private ImageIcon imgchanger(ImageIcon changeicon) {
		Image change = changeicon.getImage(); // 받은 아이콘의 이미지를 추출해서 이미지 타입으로 넣음
		Image change2 = change.getScaledInstance(470, 530, java.awt.Image.SCALE_SMOOTH); // 받은걸 크기 맞춰주고 비율을 자동으로 맞춤
		ImageIcon tt = new ImageIcon(change2); // 맞춘걸 다시 이미지 아이콘으로 변환
		return tt; // 리턴
	}

}