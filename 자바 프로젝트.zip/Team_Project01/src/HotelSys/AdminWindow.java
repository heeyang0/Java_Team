package HotelSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import HotelSys.item.JRoundButton;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class AdminWindow extends JFrame implements ActionListener {

	private JPanel contentPane;
	public JTextField textField;
	private JTable table;
	private JLabel lblNewLabel;
	private JRoundButton btnData;
	private JRoundButton btnadd;
	private JRoundButton btndelete;
	private JRoundButton btnmodify;
	private JComboBox comboBox;
	private JRoundButton btnsearch;
	private JScrollPane scrollPane;
	private boolean found;
	private String id;
	private int selectedRowIndex;
	private Object[] rowData;

	
	
	public AdminWindow(String title) {
		setTitle(title);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 772, 443);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		lblNewLabel = new JLabel("----------------------------  xx호텔  전체 예약자 명단 -------------------------");
		lblNewLabel.setFont(new Font("D2Coding", Font.PLAIN, 12));
		lblNewLabel.setBounds(141, 10, 526, 32);
		contentPane.add(lblNewLabel);

		btnData = new JRoundButton("데이터 불러오기");
		btnData.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		btnData.setBackground(new Color(219, 236, 230));
		btnData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadData();
			}
		});
		btnData.setBounds(12, 54, 124, 53);
		contentPane.add(btnData);

		btnadd = new JRoundButton("추가");
		btnadd.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		btnadd.setBackground(new Color(219, 236, 230));
		btnadd.addActionListener(this);
		btnadd.setBounds(12, 356, 78, 32);
		contentPane.add(btnadd);

		btndelete = new JRoundButton("삭제");
		btndelete.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		btndelete.setBackground(new Color(219, 236, 230));
		btndelete.addActionListener(this);
		btndelete.setBounds(102, 356, 78, 32);
		contentPane.add(btndelete);

		btnmodify = new JRoundButton("수정");
		btnmodify.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		btnmodify.setBackground(new Color(219, 236, 230));
		btnmodify.addActionListener(this);
		btnmodify.setBounds(192, 356, 78, 32);
		contentPane.add(btnmodify);

		comboBox = new JComboBox();
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "", "아이디", "이름", "전화번호", "방번호", "체크인", "체크아웃" }));
		comboBox.setBounds(273, 356, 78, 32);
		contentPane.add(comboBox);

		textField = new JTextField();
		textField.setBounds(363, 362, 286, 21);
		contentPane.add(textField);
		textField.setColumns(10);

		btnsearch = new JRoundButton("검색");
		btnsearch.setBackground(new Color(219, 236, 230));
		btnsearch.addActionListener(this);
		btnsearch.setBounds(661, 356, 78, 32);
		contentPane.add(btnsearch);

		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(151, 52, 595, 289);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		setVisible(true);
	}

	// 데이터를 로드하는 메서드
	private void loadData() {

		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);

		String sql = "SELECT * FROM hotel";
		try {
			DB.init();
			ResultSet rs = DB.getResultSet(sql);
			ResultSetMetaData metaData = rs.getMetaData();

			int cols = metaData.getColumnCount();
			String[] colName = new String[cols];

			for (int i = 0; i < colName.length; i++) {
				colName[i] = metaData.getColumnName(i + 1);
			}
			model.setColumnIdentifiers(colName);

			while (rs.next()) {
				Vector<Object> vec = new Vector<>();
				vec.add(rs.getString(1));
				vec.add(rs.getString(2));
				vec.add(rs.getString(3));
				vec.add(rs.getString(4));
				vec.add(rs.getString(5));
				vec.add(rs.getString(6));
				vec.add(rs.getInt(7));

				model.addRow(vec);
			}

			rs.close(); // ResultSet을 명시적으로 닫아줍니다.

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println("데이터 불러오기 오류");
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == btndelete) { // 삭제기능
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			int[] selectedRows = table.getSelectedRows();
			for (int i = selectedRows.length - 1; i >= 0; i--) {
				int selectedRowIndex = selectedRows[i];
				int idToDelete = (int) model.getValueAt(selectedRowIndex, 6);

				model.removeRow(selectedRowIndex);

				// DB에서 해당 아이디의 데이터 삭제
				deleteDataFromDB(idToDelete);
			}
		} else if (obj == btnsearch) { // 검색기능
			Btnsearch btnsearch = new Btnsearch(table, textField, comboBox); // 검색 메서드 호출
			btnsearch.search();

		} else if (obj == btnadd) { // 데이터 추가 기능
			String ID = JOptionPane.showInputDialog(null, "아이디 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String Name = JOptionPane.showInputDialog(null, "이름을 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String phoneNumber = JOptionPane.showInputDialog(null, "전화번호를 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String RoomNum = JOptionPane.showInputDialog(null, "방번호를 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String Checkin = JOptionPane.showInputDialog(null, "체크인 날짜를 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String CheckOut = JOptionPane.showInputDialog(null, "체크아웃 날짜를 입력하세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);
			String Rank = JOptionPane.showInputDialog(null, "순번을 적으세요:", "데이터 추가", JOptionPane.PLAIN_MESSAGE);

			// 입력된 데이터를 테이블에 추가한다.
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			Vector<Object> rowData = new Vector<>();
			rowData.add(ID);
			rowData.add(Name);
			rowData.add(phoneNumber);
			rowData.add(RoomNum);
			rowData.add(Checkin);
			rowData.add(CheckOut);
			rowData.add(Rank);

			model.addRow(rowData);

			table.setModel(model);

			String sql = "INSERT INTO hotel.hotel (아이디, 이름, 전화번호, 방번호, 체크인, 체크아웃, 순번) VALUES (?, ?, ?, ?, ?, ?, ?)";
			try {
				DB.init();
				DB.executeUpdate(sql, ID, Name, phoneNumber, RoomNum, Checkin, CheckOut, Rank);
				DB.commit(); // DB 변경 사항을 커밋
				DB.close(); // DB 커넥션을 닫습니다.
			} catch (ClassNotFoundException | SQLException ex) {
				ex.printStackTrace();
				System.out.println("데이터 추가 오류");
			}

		} else if (obj == btnmodify) {
			int selectedRowIndex = table.getSelectedRow();
			if (selectedRowIndex == -1) {
				JOptionPane.showMessageDialog(null, "수정할 행을 선택하세요.", "오류", JOptionPane.ERROR_MESSAGE);
				return;
			}

			DefaultTableModel model = (DefaultTableModel) table.getModel();
			rowData = new Object[model.getColumnCount()];
			for (int i = 0; i < rowData.length; i++) {
				rowData[i] = model.getValueAt(selectedRowIndex, i);
			}

			String ID = (String) JOptionPane.showInputDialog(null, "아이디 입력하세요:", "데이터 수정", JOptionPane.PLAIN_MESSAGE,
					null, null, rowData[0]);
			String Name = (String) JOptionPane.showInputDialog(null, "이름을 입력하세요:", "데이터 수정", JOptionPane.PLAIN_MESSAGE,
					null, null, rowData[1]);
			String phoneNumber = (String) JOptionPane.showInputDialog(null, "전화번호를 입력하세요:", "데이터 수정",
					JOptionPane.PLAIN_MESSAGE, null, null, rowData[2]);
			String RoomNum = (String) JOptionPane.showInputDialog(null, "방번호를 입력하세요:", "데이터 수정",
					JOptionPane.PLAIN_MESSAGE, null, null, rowData[3]);
			String Checkin = (String) JOptionPane.showInputDialog(null, "체크인 날짜를 입력하세요:", "데이터 수정",
					JOptionPane.PLAIN_MESSAGE, null, null, rowData[4]);
			String CheckOut = (String) JOptionPane.showInputDialog(null, "체크아웃 날짜를 입력하세요:", "데이터 수정",
					JOptionPane.PLAIN_MESSAGE, null, null, rowData[5]);
			String Rank = (String) JOptionPane.showInputDialog(null, "순번을 적으세요:", "데이터 수정", JOptionPane.PLAIN_MESSAGE,
					null, null, rowData[6]);

			model.setValueAt(ID, selectedRowIndex, 0);
			model.setValueAt(Name, selectedRowIndex, 1);
			model.setValueAt(phoneNumber, selectedRowIndex, 2);
			model.setValueAt(RoomNum, selectedRowIndex, 3);
			model.setValueAt(Checkin, selectedRowIndex, 4);
			model.setValueAt(CheckOut, selectedRowIndex, 5);
			model.setValueAt(Rank, selectedRowIndex, 6);

			modifyDataInDB(ID, Name, phoneNumber, RoomNum, Checkin, CheckOut, Rank);
		}
	}

//UPDATE hotel.hotel SET 아이디='C117', 이름='김하오', 전화번호='010-0000-0009', 방번호='룸3',
	// 체크인='2023-01-05', 체크아웃='2023-01-07' WHERE 순번=9;

	public void modifyDataInDB(String 아이디, String 이름, String 전화번호, String 방번호, String 체크인, String 체크아웃, String 순번) {
		String sql = "UPDATE hotel.hotel SET 아이디 = ?, 이름 = ?, 전화번호 = ?, 방번호 = ?, 체크인 = ?, 체크아웃 = ? WHERE 순번 = ?";
		try {
			DB.init();
			DB.executeUpdate(sql, 아이디, 이름, 전화번호, 방번호, 체크인, 체크아웃, 순번);
			DB.commit(); // 변경 내용 커밋
			DB.close();
			JOptionPane.showMessageDialog(null, "데이터가 성공적으로 수정되었습니다.", "수정 완료", JOptionPane.INFORMATION_MESSAGE);
		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			System.out.println("데이터 수정 오류");
			JOptionPane.showMessageDialog(null, "데이터 수정 중 오류가 발생했습니다.", "수정 오류", JOptionPane.ERROR_MESSAGE);
		}
	}

	// 주어진 아이디에 해당하는 데이터를 데이터베이스에서 삭제하는 역할
	static void deleteDataFromDB(int idToDelete) {
		String sql = "DELETE FROM hotel WHERE 순번 = ?";

		try {
			DB.init();
			DB.executeUpdate(sql, idToDelete + "");
		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			System.out.println("데이터 삭제 오류");
		}
	}
}