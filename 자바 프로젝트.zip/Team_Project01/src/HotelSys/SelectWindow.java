package HotelSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import HotelSys.item.JRoundButton;
import HotelSys.item.RoundedJTextField;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;

public class SelectWindow extends JFrame implements MouseListener, ActionListener {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private String id;
	private JPanel enter;
	private JPanel selec;
	private JPanel qna;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_3;
	private JRoundButton btnNewButton;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public SelectWindow(String id) {
		this.id = id;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(444, 586);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		enter = new JPanel();
		enter.setBackground(new Color(255, 0, 0, 0));
		enter.setBounds(153, 85, 145, 70);
		contentPane.add(enter);
		enter.setLayout(new BorderLayout(0, 0));
		enter.addMouseListener(this);

		lblNewLabel_1 = new JLabel("\uC608\uC57D\uD558\uAE30");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(128, 0, 0));
		lblNewLabel_1.setFont(new Font("휴먼둥근헤드라인", Font.PLAIN, 27));
		lblNewLabel_1.setBackground(Color.WHITE);
		enter.add(lblNewLabel_1, BorderLayout.CENTER);

		selec = new JPanel();
		selec.setBackground(new Color(255, 0, 0, 0));
		selec.setBounds(153, 168, 145, 70);
		contentPane.add(selec);
		selec.setLayout(new BorderLayout(0, 0));
		selec.addMouseListener(this);

		lblNewLabel_2 = new JLabel("\uC870\uD68C\uD558\uAE30");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(new Color(128, 64, 64));
		lblNewLabel_2.setFont(new Font("휴먼둥근헤드라인", Font.PLAIN, 27));
		lblNewLabel_2.setBackground(Color.WHITE);
		selec.add(lblNewLabel_2);

		qna = new JPanel();
		qna.setBackground(new Color(255, 0, 0, 0));
		qna.setBounds(175, 254, 90, 70);
		contentPane.add(qna);
		qna.setLayout(new BorderLayout(0, 0));
		qna.addMouseListener(this);

		lblNewLabel_3 = new JLabel("QnA");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(new Color(128, 64, 64));
		lblNewLabel_3.setFont(new Font("휴먼둥근헤드라인", Font.ITALIC, 27));
		lblNewLabel_3.setBackground(Color.WHITE);
		qna.add(lblNewLabel_3, BorderLayout.CENTER);
		
		btnNewButton = new JRoundButton("LogOut");
		btnNewButton.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		btnNewButton.setContentAreaFilled(false); // 배경 색 없애기
		btnNewButton.setOpaque(false); // 배경 불투명 설정 해제
		btnNewButton.setBounds(339, 10, 91, 23);
		btnNewButton.addActionListener(this);
		contentPane.add(btnNewButton);

		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("images/haha.png"));
		lblNewLabel.setBounds(0, 0, 430, 549);
		contentPane.add(lblNewLabel);

		setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Object obj = e.getSource();

		if (obj == enter) { // 예약창
			setVisible(false);
			new Reservation_gui(id);
		}
		if (obj == selec) { // 조회창
			setVisible(false);
			new Reservation_check(id);
		}
		if (obj == qna) { // qna창
			setVisible(true);
			new QRcode("Q&A Window");

		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obi = e.getSource();
		if(obi == btnNewButton) {
			setVisible(false);
			new Login("로그인창");
		}
	}
}
