package HotelSys;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import HotelSys.item.JRoundButton;

import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

public class CardPay extends JFrame implements ItemListener {

	private JPanel contentPane;
	private JComboBox bankk;
	private JTextField textField_3;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_2;
	private String selectedBank;
	private String selectedCardType;
	private String cardNumber;
	private String expirationDate;
	private String cvc;
	private String password;
	private JCheckBox chckbxNewCheckBox;
	private JRoundButton btnNewButton;

	public CardPay(String id, String name, String phone_num, String point, String cKi, String cKo, long difference) {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		JPanel scrollContent = new JPanel();
		scrollContent.setBackground(new Color(255, 255, 255));
		scrollContent.setLayout(null);
		setLocationRelativeTo(this);
		JLabel lblNewLabel = new JLabel("신용·체크카드");
		lblNewLabel.setBounds(133, 10, 179, 34);
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 26));
		scrollContent.add(lblNewLabel);

		Toolkit kit = Toolkit.getDefaultToolkit(); // icon
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(48, 71, 326, 112);
		scrollContent.add(panel_1);
		panel_1.setLayout(new GridLayout(3, 3, 3, 3));

		ButtonGroup buttonGroup = new ButtonGroup();
		ActionListener actionListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JButton button = (JButton) e.getSource();
				button.setBackground(Color.RED);

			}
		};

		JButton btn = new JButton();
		btn.setBackground(new Color(255, 255, 255));
		btn.setIcon(new ImageIcon("images/hd.jpg"));
		btn.addActionListener(actionListener);
		panel_1.add(btn);

		JButton btn1 = new JButton();
		btn1.setBackground(new Color(255, 255, 255));
		btn1.setIcon(new ImageIcon("images/hn.jpg"));
		btn1.addActionListener(actionListener);
		panel_1.add(btn1);

		JButton btn12 = new JButton();
		btn12.setBackground(new Color(255, 255, 255));
		btn12.setIcon(new ImageIcon("images/kb.jpg"));
		btn12.addActionListener(actionListener);
		panel_1.add(btn12);

		JButton btn14 = new JButton();
		btn14.setBackground(new Color(255, 255, 255));
		btn14.setIcon(new ImageIcon("images/nh.jpg"));
		btn14.addActionListener(actionListener);
		panel_1.add(btn14);

		JButton btn13 = new JButton();
		btn13.setBackground(new Color(255, 255, 255));
		btn13.setIcon(new ImageIcon("images/rd.jpg"));
		btn13.addActionListener(actionListener);
		panel_1.add(btn13);

		JButton btn5 = new JButton();
		btn5.setBackground(new Color(255, 255, 255));
		btn5.setIcon(new ImageIcon("images/sh.jpg"));
		btn5.addActionListener(actionListener);
		panel_1.add(btn5);

		JButton btn6 = new JButton();
		btn6.setBackground(new Color(255, 255, 255));
		btn6.setIcon(new ImageIcon("images/ss.jpg"));
		btn6.addActionListener(actionListener);
		panel_1.add(btn6);

		JButton btn7 = new JButton();
		btn7.setBackground(new Color(255, 255, 255));
		btn7.setIcon(new ImageIcon("images/wr.jpg"));
		btn7.addActionListener(actionListener);
		panel_1.add(btn7);

		JButton btn8 = new JButton();
		btn8.setBackground(new Color(255, 255, 255));
		btn8.setIcon(new ImageIcon("images/bc.jpg"));
		btn8.addActionListener(actionListener);
		panel_1.add(btn8);

		buttonGroup.add(btn);
		buttonGroup.add(btn1);
		buttonGroup.add(btn12);
		buttonGroup.add(btn13);
		buttonGroup.add(btn14);
		buttonGroup.add(btn5);
		buttonGroup.add(btn6);
		buttonGroup.add(btn7);
		buttonGroup.add(btn8);

		String[] items = { "일시불", "2개월(무이자)", "3개월(무이자)", "6개월(무이자)", "7개월", "10개월", "12개월" };
		bankk = new JComboBox<>();
		bankk.setModel(new DefaultComboBoxModel<>(items));

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(23, 193, 383, 285);
		scrollContent.add(panel_2);
		panel_2.setLayout(null);
		JComboBox<String> comboBox = new JComboBox<>();
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.setModel(new DefaultComboBoxModel<>(items));
		comboBox.setBounds(96, 96, 113, 23);
		panel_2.add(comboBox);

		JLabel lblNewLabel_1 = new JLabel("할부기간");
		lblNewLabel_1.setBounds(12, 100, 69, 19);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));

		JLabel lblNewLabel_1_1 = new JLabel("카드구분");
		lblNewLabel_1_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(12, 58, 69, 19);
		panel_2.add(lblNewLabel_1_1);

		JRadioButton rdbtnNewRadioButton = new JRadioButton("개인카드");
		rdbtnNewRadioButton.setBackground(new Color(255, 255, 255));
		rdbtnNewRadioButton.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		rdbtnNewRadioButton.setBounds(96, 57, 77, 23);
		panel_2.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("법인카드");
		rdbtnNewRadioButton_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		rdbtnNewRadioButton_1.setBackground(new Color(255, 255, 255));
		rdbtnNewRadioButton_1.setBounds(192, 57, 77, 23);
		panel_2.add(rdbtnNewRadioButton_1);

		ButtonGroup users = new ButtonGroup();
		users.add(rdbtnNewRadioButton);
		users.add(rdbtnNewRadioButton_1);

		JLabel lblNewLabel_1_2 = new JLabel("카드번호");
		lblNewLabel_1_2.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(12, 139, 69, 19);
		panel_2.add(lblNewLabel_1_2);

		textField_3 = new JTextField();
		textField_3.setForeground(Color.GRAY);
		textField_3.setColumns(10);
		textField_3.setBounds(96, 177, 113, 21);
		textField_3.setText("yy/mm/dd");
		textField_3.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				if (textField_3.getText().equals("yy/mm/dd")) {
					textField_3.setText("");
					textField_3.setForeground(Color.BLACK);
				}
			}

			public void focusLost(FocusEvent e) {
				if (textField_3.getText().isEmpty()) {
					textField_3.setText("yy/mm/dd");
					textField_3.setForeground(Color.GRAY);
				}
			}
		});
		panel_2.add(textField_3);

		JLabel lblNewLabel_1_2_1 = new JLabel("유효기간");
		lblNewLabel_1_2_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_2_1.setBounds(12, 179, 69, 19);
		panel_2.add(lblNewLabel_1_2_1);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(96, 140, 201, 21);

		panel_2.add(textField_1);

		JLabel lblNewLabel_1_2_1_1 = new JLabel("CVC");
		lblNewLabel_1_2_1_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1.setBounds(12, 218, 69, 19);
		panel_2.add(lblNewLabel_1_2_1_1);

		textField_2 = new JTextField();
		textField_2.setForeground(Color.GRAY);
		textField_2.setColumns(10);
		textField_2.setBounds(96, 219, 113, 21);
		panel_2.add(textField_2);

		JLabel lblNewLabel_1_2_1_1_1 = new JLabel("비밀번호");
		lblNewLabel_1_2_1_1_1.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1_1.setBounds(12, 253, 69, 19);
		panel_2.add(lblNewLabel_1_2_1_1_1);

		textField_4 = new JTextField();
		textField_4.setText("앞 두자리");
		textField_4.setForeground(Color.GRAY);
		textField_4.setColumns(10);
		textField_4.setBounds(96, 254, 62, 21);
		textField_4.addFocusListener(new FocusListener() {

			public void focusGained(FocusEvent e) {
				if (textField_4.getText().equals("앞 두자리")) {
					textField_4.setText("");
					textField_4.setForeground(Color.BLACK);
				}
			}

			public void focusLost(FocusEvent e) {
				if (textField_4.getText().isEmpty()) {
					textField_4.setText("앞 두자리");
					textField_4.setForeground(Color.GRAY);
				}
			}
		});

		panel_2.add(textField_4);

		JLabel lblNewLabel_2 = new JLabel("●●");
		lblNewLabel_2.setBounds(159, 257, 50, 15);

		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_1_1_2 = new JLabel("카드사");
		lblNewLabel_1_1_2.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 15));
		lblNewLabel_1_1_2.setBounds(12, 19, 69, 19);
		panel_2.add(lblNewLabel_1_1_2);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(96, 19, 50, 15);
		panel_2.add(lblNewLabel_4);

		JLabel lblNewLabel_1_1_1 = new JLabel("결제정보");
		lblNewLabel_1_1_1.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 19));
		lblNewLabel_1_1_1.setBounds(23, 475, 82, 40);
		scrollContent.add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_3 = new JLabel("총 결제 금액");
		lblNewLabel_1_3.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 17));
		lblNewLabel_1_3.setBounds(23, 511, 117, 34);
		scrollContent.add(lblNewLabel_1_3);
		scrollContent.setBounds(0, 0, 436, 663);
		contentPane.add(scrollContent);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setBounds(186, 511, 220, 34);

		lblNewLabel_3.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 20));
		// 여기에 금액
		if (point == "싱글룸") {
			lblNewLabel_3.setText("" + difference * 70000 + "원");
		}
		if (point == "더블룸") {
			lblNewLabel_3.setText("" + difference * 100000 + "원");
		}
		if (point == "트윈룸") {
			lblNewLabel_3.setText("" + difference * 100000 + "원");
		}
		if (point == "스위트룸") {
			lblNewLabel_3.setText("" + difference * 200000 + "원");
		}

		scrollContent.add(lblNewLabel_3);

		btnNewButton = new JRoundButton("결제하기");
		btnNewButton.setForeground(new Color(68, 68, 68));
		btnNewButton.setBackground(new Color(152, 245, 159));
		btnNewButton.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btnNewButton.setBounds(58, 595, 317, 40);
		btnNewButton.setEnabled(false);
		btnNewButton.addActionListener(new ActionListener() {
			private String colslangth;

			public void actionPerformed(ActionEvent e) {
				selectedBank = bankk.getSelectedItem().toString();
				selectedCardType = rdbtnNewRadioButton.isSelected() ? "개인카드" : "법인카드";
				cardNumber = textField_1.getText();
				expirationDate = textField_3.getText();
				cvc = textField_2.getText();
				password = textField_3.getText();

				// 필드값이 모두 입력되었는지 확인합니다.
				if (selectedBank.isEmpty() || selectedCardType.isEmpty() || cardNumber.isEmpty()
						|| expirationDate.isEmpty() || cvc.isEmpty() || password.isEmpty()) {
					JOptionPane.showMessageDialog(null, "모든 정보를 입력해주세요.", "경고", JOptionPane.WARNING_MESSAGE);
				} else {

					try {
						DB.init();
						String length = "SELECT COUNT(순번) FROM hotel";
						ResultSet rs = DB.getResultSet(length);
						if (rs.next()) {
							int cols = rs.getInt(1);
							colslangth = String.valueOf(cols + 1);
						}

						System.out.println(id + "\t" + "name" + "\t" + "phone_num" + "\t" + point + "\t" + cKi + "\t"
								+ cKo + "\t" + colslangth);

						String sql = "INSERT INTO hotel (아이디, 이름, 전화번호, 방번호, 체크인, 체크아웃) VALUES (?, ?, ?, ?, ?, ?)";
						DB.executeUpdate(sql, id, name, phone_num, point, cKi, cKo);
						DB.commit(); // DB 변경 사항을 커밋
						DB.close(); // DB 커넥션을 닫습니다.

						JOptionPane.showMessageDialog(null, "예약이 완료되었습니다.");
						// System.exit(0); //시스템 강제종료

					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}

					// 필드값이 모두 입력되었으면 알림 창을 띄웁니다.
					JOptionPane.showMessageDialog(null, "결제가 완료되었습니다.");
					setVisible(false);
					int answer = JOptionPane.showConfirmDialog(null, "홈으로 돌아가시겠습니까?", "confirm",
							JOptionPane.YES_NO_OPTION);
					if (answer == JOptionPane.YES_OPTION) {
						// 사용자가 yes를 눌렀을 떄
						new SelectWindow(id);
					} else {
						// 사용자가 NO 외 값 입력시
						JOptionPane.showMessageDialog(null, "로그아웃후 프로그램이 종료 됩니다.");
						System.exit(0); // 시스템 강제종료
					}
				}
			}
		});

		scrollContent.add(btnNewButton);

		chckbxNewCheckBox = new JCheckBox("[필수] 결제 서비스 이용약관, 개인정보 처리 동의");
		chckbxNewCheckBox.setBackground(new Color(255, 255, 255));
		chckbxNewCheckBox.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 12));
		chckbxNewCheckBox.setBounds(16, 562, 358, 23);
		chckbxNewCheckBox.addItemListener(this);
		scrollContent.add(chckbxNewCheckBox);

		setVisible(true);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED)
			btnNewButton.setEnabled(true);
		else
			btnNewButton.setEnabled(false);

	}
}