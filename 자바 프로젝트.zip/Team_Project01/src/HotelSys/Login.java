package HotelSys;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Any;

import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class Login extends JFrame implements Runnable {

   private JPanel contentPane;
   private JPasswordField passwordField_1;
   private JTextField idField;
   private JPasswordField passwordField;

   /**
    * Launch the application.
    */
   

   /**
    * Create the frame.
    */

   public Login(String title) {
      setTitle(title);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 760, 500);
      setLocationRelativeTo(null);

      contentPane = new JPanel();
      contentPane.setBackground(new Color(176, 224, 238));
      contentPane.setForeground(new Color(176, 224, 238));

      setContentPane(contentPane);
      contentPane.setLayout(null);

      Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
      Image img = kit.getImage("images/icon.png");
      this.setIconImage(img);
      JLabel imageLabel = new JLabel();

      JPanel panel = new JPanel();
      panel.setBounds(317, 62, 399, 355);
      panel.setBackground(new Color(0, 0, 0, 122));
      contentPane.add(panel);
      panel.setLayout(null);

      JLabel lblNewLabel = new JLabel("호텔관리시스템");
      lblNewLabel.setForeground(new Color(0, 0, 0));
      lblNewLabel.setEnabled(false);
      lblNewLabel.setBackground(new Color(128, 255, 0));
      lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 26));
      lblNewLabel.setBounds(115, 38, 211, 48);
      panel.add(lblNewLabel);

      JLabel lblNewLabel_1_1 = new JLabel("PW : ");
      lblNewLabel_1_1.setEnabled(false);
      lblNewLabel_1_1.setBounds(80, 205, 39, 15);
      panel.add(lblNewLabel_1_1);

      idField = new JTextField();
      idField.setColumns(10);
      idField.setBounds(116, 136, 96, 21);
      panel.add(idField);

      JButton loginBtn = new JButton("로그인");
      loginBtn.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
      loginBtn.setBackground(new Color(255, 255, 255));
      loginBtn.setBounds(244, 136, 82, 87);
      panel.add(loginBtn);

      RoundedButton adminBtn = new RoundedButton("관리자모드");
      adminBtn.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
      adminBtn.setBackground(new Color(184, 232, 254));
      adminBtn.setBounds(96, 269, 105, 23);
      panel.add(adminBtn);

      RoundedButton btnNewButton_2 = new RoundedButton("회원가입");
      btnNewButton_2.setFont(new Font("한컴 말랑말랑 Regular", Font.PLAIN, 14));
      btnNewButton_2.setBackground(new Color(184, 232, 254));
      btnNewButton_2.setBounds(213, 269, 102, 23);
      panel.add(btnNewButton_2);

      JLabel lblNewLabel_1_1_1 = new JLabel("ID : ");
      lblNewLabel_1_1_1.setEnabled(false);
      lblNewLabel_1_1_1.setBounds(88, 139, 31, 15);
      panel.add(lblNewLabel_1_1_1);

      passwordField = new JPasswordField();
      passwordField.setBounds(116, 202, 96, 21);
      panel.add(passwordField);

      loginBtn.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {
            String id = idField.getText();
            String password = new String(passwordField.getPassword());

            boolean loginSuccessful = authenticateUser(id, password);

            if (loginSuccessful) {
               JOptionPane.showMessageDialog(null, "엄청난호텔에 오신것을 환영합니다.");
               setVisible(false);
               new SelectWindow(id);

            } else {
               JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 잘못되었습니다. 다시 확인해주세요.");

            }
         }

         private boolean authenticateUser(String ID, String PASSWORD) {
            String sql = "SELECT * FROM member WHERE id = '" + ID + "' AND password = '" + PASSWORD + "'";
            try {
               DB.init();
               Connection connection = DB.getConnection();
               Statement statement = connection.createStatement();
               ResultSet resultSet = statement.executeQuery(sql);

               // 결과가 존재하는지 확인
               boolean loginSuccessful = resultSet.next();

               resultSet.close();
               statement.close();
               connection.close();

               return loginSuccessful;
            } catch (ClassNotFoundException | SQLException e) {
               ((Throwable) e).printStackTrace();
            }
            return false;
         }
      });

      adminBtn.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {

            String id2 = idField.getText();
            String password2 = new String(passwordField.getPassword());

            if (id2.equals("def") && password2.equals("5678")) {

               Object obj = e.getSource();

               if (obj == adminBtn) {
                  AdminWindow adminWindow = new AdminWindow("관리자 모드");
                  adminWindow.setVisible(true);
               }
            } else {
               JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 잘못되었습니다. 다시 확인해 주세요.");
            }

         }
      });
      btnNewButton_2.addActionListener(new ActionListener() {

         @Override
         public void actionPerformed(ActionEvent e) {

            Object obk = e.getSource();

            if (obk == btnNewButton_2) {
               setVisible(false);
               new Join();
            }
         }
      });

      getContentPane().add(panel);
      
            JLabel lblNewLabel_1 = new JLabel("");
            lblNewLabel_1.setIcon(new ImageIcon(Login.class.getResource("/images/login.png")));
            lblNewLabel_1.setBounds(0, 0, 746, 477);
            contentPane.add(lblNewLabel_1);

      setVisible(true);

   }

   @Override
   public void run() {
      // TODO Auto-generated method stub

   }
}