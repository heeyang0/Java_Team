package HotelSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import HotelSys.item.JRoundButton;
import HotelSys.item.Pwtp;
import HotelSys.item.RoundedJTextField;
import HotelSys.item.Pwtp;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;

public class Join extends JFrame implements ActionListener {

	private JPanel contentPane;
	private RoundedJTextField textField;
	private RoundedJTextField textField_2;
	private JRoundButton btnNewButton;
	private JLabel lblNewLabel_3;
	private JButton btnNewButton_1;
	private RoundedJTextField textField_2_1_1;
	private RoundedJTextField textField_2_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Join() {
		setBackground(new Color(255, 255, 255));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(120, 120, 182));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		JRoundButton rbtn1 = new JRoundButton("");
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(this);
		JLabel lblNewLabel = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lblNewLabel.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 26));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(47, 10, 107, 31);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\uC544\uC774\uB514");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1.setBounds(47, 251, 57, 15);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(47, 317, 57, 15);
		contentPane.add(lblNewLabel_1_1);

		Toolkit kit = Toolkit.getDefaultToolkit(); // icon
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		textField = new RoundedJTextField(123);
		textField.setBounds(47, 276, 250, 31);
		contentPane.add(textField);

		btnNewButton = new JRoundButton("Sign UP");
		btnNewButton.setText("\uAC00\uC785\uD558\uAE30 !");
		btnNewButton.addActionListener(this);
		btnNewButton.setForeground(new Color(64, 0, 64));
		btnNewButton.setToolTipText("\uAC00\uC785\uD558\uAE30");
		btnNewButton.setBackground(new Color(229, 232, 255));
		btnNewButton.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		btnNewButton.setBounds(47, 476, 250, 42);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel_1_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uD655\uC778");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(47, 383, 107, 15);
		contentPane.add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("\uC774\uBA54\uC77C\uC8FC\uC18C");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1_2.setBounds(47, 185, 69, 15);
		contentPane.add(lblNewLabel_1_2);

		textField_2 = new RoundedJTextField(123);
		textField_2.setBounds(47, 210, 250, 31);
		contentPane.add(textField_2);

		JLabel lblNewLabel_2 = new JLabel("\uC774\uBBF8 \uACC4\uC815\uC774 \uC788\uC2B5\uB2C8\uAE4C?");
		lblNewLabel_2.setBounds(57, 532, 127, 15);
		contentPane.add(lblNewLabel_2);

		btnNewButton_1 = new JButton("\uB85C\uADF8\uC778\uD558\uAE30");
		btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBackground(new Color(120, 120, 182));
		btnNewButton_1.setBounds(186, 528, 98, 23);
		contentPane.add(btnNewButton_1);

		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("굴림", Font.PLAIN, 15));
		lblNewLabel_3.setBackground(new Color(255, 0, 0));
		lblNewLabel_3.setForeground(new Color(255, 128, 64));
		lblNewLabel_3.setBounds(47, 441, 165, 23);
		contentPane.add(lblNewLabel_3);

		textField_2_1 = new RoundedJTextField(123);
		textField_2_1.setBounds(47, 144, 250, 31);
		contentPane.add(textField_2_1);

		JLabel lblNewLabel_1_2_1 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_1_2_1.setForeground(Color.WHITE);
		lblNewLabel_1_2_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1_2_1.setBounds(47, 119, 69, 15);
		contentPane.add(lblNewLabel_1_2_1);

		JLabel lblNewLabel_1_2_1_1 = new JLabel("\uC774\uB984");
		lblNewLabel_1_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_2_1_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		lblNewLabel_1_2_1_1.setBounds(47, 51, 69, 15);
		contentPane.add(lblNewLabel_1_2_1_1);

		// 이름
		textField_2_1_1 = new RoundedJTextField(123);
		textField_2_1_1.setBounds(47, 76, 250, 31);
		contentPane.add(textField_2_1_1);

		passwordField = new Pwtp(15);
		passwordField.setBackground(new Color(255, 255, 255));
		passwordField.setForeground(new Color(0, 0, 0));
		passwordField.setBounds(47, 342, 250, 31);
		contentPane.add(passwordField);

		passwordField_1 = new Pwtp(15);
		passwordField_1.setBounds(47, 408, 250, 31);
		contentPane.add(passwordField_1);
		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		String name = textField_2_1_1.getText();
		String phoneNumber = textField_2_1.getText();
		String Email = textField_2.getText();
		String ID = textField.getText();
		String PW = new String(passwordField.getPassword());
		String PW2 = new String(passwordField_1.getPassword());

		// Sisn UP 버튼
		if (btnNewButton == obj) {
			if (!PW.equals(PW2)) { // pw랑 pw확인이 같은지 확인
				lblNewLabel_3.setText("비밀번호가 다릅니다.");
			} else {
				lblNewLabel_3.setText("");

				try {
					DB.init();
					String sql = "INSERT INTO member (이름, 전화번호, 이메일, id, password) VALUES (?, ?, ?, ?, ?)";
					DB.executeUpdate(sql, name, phoneNumber, Email, ID, PW);
					DB.commit(); // DB 변경 사항을 커밋
					DB.close(); // DB 커넥션을 닫습니다.

					JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");
					setVisible(false); // 가입창 안보이게하기
					new Login("로그인창");

				} catch (ClassNotFoundException e1) {
					e1.printStackTrace(); // 들어갈 곳을 못찾을때
				} catch (SQLException e1) {
					lblNewLabel_3.setText("아이디가 중복됐습니다."); // 아이디 중복일때 뜨는듯

				}
			}
		}
		// 로그인하기 버튼
		if (btnNewButton_1 == obj) {
			setVisible(false); // 가입창 안보이게하기
			new Login("로그인창");
		}

	}
}