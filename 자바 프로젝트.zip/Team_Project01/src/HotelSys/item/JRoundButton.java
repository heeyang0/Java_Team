package HotelSys.item;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class JRoundButton extends JButton {

	public JRoundButton(String label) {
		super(label);
		setOpaque(false);
		setBorderPainted(false);
	}

	@Override
	protected void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		Dimension d = getSize();
		Shape shape = new RoundRectangle2D.Float(0, 0, d.width - 1, d.height - 1, d.height - 10, d.height - 10);
		g2.setPaint(getBackground());
		g2.fill(shape);
		g2.setPaint(getForeground());
		FontMetrics fm = g2.getFontMetrics();
		Rectangle2D r = fm.getStringBounds(getText(), g);
		float x = (float) (d.width - r.getWidth()) / 2;
		float y = (float) (d.height - r.getHeight()) / 2 + fm.getAscent();
		g2.drawString(getText(), x, y);
		g2.dispose();
		super.paintComponent(g);
	}

	@Override
	protected void paintBorder(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		Dimension d = getSize();
		Shape shape = new RoundRectangle2D.Float(0, 0, d.width - 1, d.height - 1, d.height - 10, d.height - 10);
		g2.setPaint(getForeground());
		g2.draw(shape);
		g2.dispose();
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("JRoundButton Example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new FlowLayout());
		JRoundButton button = new JRoundButton("Button");
		frame.add(button);
		JButton normalButton = new JButton("Normal Button");
		frame.add(normalButton);
		frame.setSize(300, 100);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}