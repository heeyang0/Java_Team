package HotelSys;

import java.sql.*;

public class Example {
	public static void main(String[] args) {

		Connection conn = null;
		PreparedStatement pstmt = null; // sql코드 받을때
		ResultSet rs = null;

		try {
			// JDBC 드라이버 로딩
			Class.forName("com.mysql.cj.jdbc.Driver");

			// DB 연결
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel", "root", "1234");

			// SQL 쿼리 작성
			String sql = "SELECT 전화번호 FROM member WHERE id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "asd");

			// SQL 실행
			rs = pstmt.executeQuery();

			// 결과 출력
			if (rs.next()) {
				String name = rs.getString(1);
				System.out.println(name);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			// 리소스 해제
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}
}