package HotelSys;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import HotelSys.Join;
import HotelSys.item.JRoundButton;
import net.codejava.swing.DateLabelFormatter;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;
import javax.swing.JTextField;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.SwingConstants;

public class Reservation_gui extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JRoundButton btnNewButton;
	private UtilDateModel model;
	private UtilDateModel model2;
	private ImageIcon sin = new ImageIcon("images/sin.png");
	private ImageIcon dob = new ImageIcon("images/dob.png");
	private ImageIcon twn = new ImageIcon("images/twn.png");
	private ImageIcon swt = new ImageIcon("images/swt.png");
	private JRoundButton btnNewButton_2;
	private JRoundButton btnNewButton_3;
	private JRoundButton btnNewButton_4;
	private String id;
	private JDatePickerImpl datePicker2;
	private JDatePickerImpl datePicker;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_7_1_1_1;
	private JLabel lblNewLabel_7_1_1;
	private JLabel lblNewLabel_7_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_1_1;
	private JLabel lblNewLabel_1_2;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private long difference = 0; // 캘린더 날짜 차이 가져온거 들어가는 변수

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Reservation_gui(String id) {
		this.id = id;
		setTitle("\uC608\uC57D\uCC3D");
		setResizable(false);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 570, 610);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(226, 222, 244));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel dayc = new JLabel("Day");
		dayc.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		dayc.setHorizontalAlignment(JLabel.CENTER);
		dayc.setBounds(252, 10, 56, 30);
		getContentPane().add(dayc);

		// 날짜선택부
		date();

		JLabel roomc = new JLabel("ROOM");
		roomc.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		roomc.setHorizontalAlignment(JLabel.CENTER);
		roomc.setBounds(244, 100, 77, 30);
		getContentPane().add(roomc);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(226, 222, 244));
		panel.setBounds(25, 130, 500, 420);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(4, 1, 0, 5));

		// 싱글룸 선택부
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);

		ImageIcon sinimg = new ImageIcon("images/1.jpg");
		ImageIcon sinimage = imgchanger(sinimg);
		panel_1.setLayout(null);

		btnNewButton = new JRoundButton("예약");
		btnNewButton.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(202, 142, 180));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(this);

		lblNewLabel_7 = new JLabel("원");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 17));
		lblNewLabel_7.setVisible(false);

		lblNewLabel = new JLabel("70000");
		lblNewLabel.setVisible(false);

		lblNewLabel_2 = new JLabel("0");
		lblNewLabel_2.setVisible(false);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		lblNewLabel_2.setBounds(428, 77, 45, 17);
		panel_1.add(lblNewLabel_2);
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 17));
		lblNewLabel.setBounds(316, 71, 100, 29);
		panel_1.add(lblNewLabel);
		lblNewLabel_7.setBounds(416, 71, 16, 29);
		panel_1.add(lblNewLabel_7);
		btnNewButton.setBounds(416, 10, 75, 45);
		panel_1.add(btnNewButton);
		JLabel sinrm = new JLabel(sinimage);
		sinrm.setBounds(0, 0, 500, 101);
		panel_1.add(sinrm);

		// 더블룸 선택부
		JPanel panel_2 = new JPanel();
		panel.add(panel_2);
		ImageIcon dobimg = new ImageIcon("images/2.jpg");
		ImageIcon dobimage = imgchanger(dobimg);
		panel_2.setLayout(null);

		btnNewButton_2 = new JRoundButton("\uC608\uC57D");
		btnNewButton_2.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.setForeground(new Color(202, 142, 180));
		btnNewButton_2.addActionListener(this);

		lblNewLabel_7_1 = new JLabel("원");
		lblNewLabel_7_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_1.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 17));
		lblNewLabel_7_1.setVisible(false);

		lblNewLabel_1 = new JLabel("100000");
		lblNewLabel_1.setVisible(false);

		lblNewLabel_3 = new JLabel("0");
		lblNewLabel_3.setVisible(false);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		lblNewLabel_3.setBounds(428, 77, 45, 17);
		panel_2.add(lblNewLabel_3);
		lblNewLabel_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(316, 71, 100, 29);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_7_1.setBounds(416, 71, 16, 29);
		panel_2.add(lblNewLabel_7_1);
		btnNewButton_2.setBounds(420, 10, 75, 45);
		panel_2.add(btnNewButton_2);
		JLabel dobrm = new JLabel(dobimage);
		dobrm.setBounds(0, 0, 500, 101);
		panel_2.add(dobrm);

		// 트윈룸 선택부
		JPanel panel_3 = new JPanel();
		panel.add(panel_3);
		ImageIcon twnimg = new ImageIcon("images/3.jpg");
		ImageIcon twnimage = imgchanger(twnimg);
		panel_3.setLayout(null);

		btnNewButton_3 = new JRoundButton("\uC608\uC57D");
		btnNewButton_3.setForeground(new Color(202, 142, 180));
		btnNewButton_3.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		btnNewButton_3.setBackground(new Color(255, 255, 255));
		btnNewButton_3.addActionListener(this);

		lblNewLabel_7_1_1 = new JLabel("원");
		lblNewLabel_7_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_1_1.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 17));
		lblNewLabel_7_1_1.setVisible(false);

		lblNewLabel_1_1 = new JLabel("100000");
		lblNewLabel_1_1.setVisible(false);

		lblNewLabel_4 = new JLabel("0");
		lblNewLabel_4.setVisible(false);
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		lblNewLabel_4.setBounds(428, 77, 45, 17);
		panel_3.add(lblNewLabel_4);
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 17));
		lblNewLabel_1_1.setBounds(316, 71, 100, 29);
		panel_3.add(lblNewLabel_1_1);
		lblNewLabel_7_1_1.setBounds(416, 71, 16, 29);
		panel_3.add(lblNewLabel_7_1_1);
		btnNewButton_3.setBounds(420, 10, 75, 45);
		panel_3.add(btnNewButton_3);
		JLabel twnrm = new JLabel(twnimage);
		twnrm.setBounds(0, 0, 500, 101);
		panel_3.add(twnrm);

		// 트리플룸 선택부
		JPanel panel_4 = new JPanel();
		panel.add(panel_4);
		ImageIcon swtimg = new ImageIcon("images/4.jpg");
		ImageIcon swtimage = imgchanger(swtimg);
		panel_4.setLayout(null);

		btnNewButton_4 = new JRoundButton("\uC608\uC57D");
		btnNewButton_4.setForeground(new Color(202, 142, 180));
		btnNewButton_4.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 12));
		btnNewButton_4.setBackground(new Color(255, 255, 255));
		btnNewButton_4.setBounds(420, 10, 75, 45);
		btnNewButton_4.addActionListener(this);

		lblNewLabel_7_1_1_1 = new JLabel("원");
		lblNewLabel_7_1_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_7_1_1_1.setFont(new Font("KoPub돋움체 Bold", Font.PLAIN, 17));
		lblNewLabel_7_1_1_1.setVisible(false);

		lblNewLabel_1_2 = new JLabel("200000");
		lblNewLabel_1_2.setVisible(false);

		lblNewLabel_5 = new JLabel("0");
		lblNewLabel_5.setVisible(false);
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_5.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 15));
		lblNewLabel_5.setBounds(428, 77, 45, 17);
		panel_4.add(lblNewLabel_5);
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setFont(new Font("KoPub돋움체 Bold", Font.BOLD, 17));
		lblNewLabel_1_2.setBounds(316, 71, 100, 29);
		panel_4.add(lblNewLabel_1_2);
		lblNewLabel_7_1_1_1.setBounds(416, 71, 16, 29);
		panel_4.add(lblNewLabel_7_1_1_1);
		panel_4.add(btnNewButton_4);
		JLabel swtrm = new JLabel(swtimage);
		swtrm.setBounds(0, 0, 500, 101);
		panel_4.add(swtrm);

		Toolkit kit = Toolkit.getDefaultToolkit(); // 아이콘
		Image img = kit.getImage("images/icon.png");
		this.setIconImage(img);

		setVisible(true);
	}
	
	// 이미지 비율 맞춰주는거
	private ImageIcon imgchanger(ImageIcon changeicon) { 
		Image change = changeicon.getImage(); // 받은 아이콘의 이미지를 추출해서 이미지 타입으로 넣음
		Image change2 = change.getScaledInstance(500, 100, java.awt.Image.SCALE_SMOOTH); // 받은걸 크기 맞춰주고 비율을 자동으로 맞춤
		ImageIcon tt = new ImageIcon(change2); // 맞춘걸 다시 이미지 아이콘으로 변환
		return tt; // 리턴
	}

	private void date() {

		JPanel date1 = new JPanel();
		date1.setBackground(new Color(226, 222, 244));
		date1.setLayout(new GridLayout(2, 1, 0, -10));
		// 체크인 글자
		JLabel dayl = new JLabel("Check IN");
		dayl.setBackground(new Color(202, 142, 180));
		dayl.setForeground(new Color(0, 0, 0));
		dayl.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		dayl.setHorizontalAlignment(JLabel.CENTER);
		date1.add(dayl);

		// 체크인 캘린더
		model = new UtilDateModel();
		JDatePanelImpl datePanel = new JDatePanelImpl(model);
		datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
		datePicker.getJFormattedTextField().setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 15));
		datePicker.setBackground(new Color(226, 222, 244));
		datePicker.getJFormattedTextField().setBackground(new Color(207, 201, 237));
		date1.add(datePicker);
		date1.setBounds(80, 30, 160, 70);
		getContentPane().add(date1);

		JPanel date2 = new JPanel();
		date2.setBackground(new Color(226, 222, 244));
		date2.setLayout(new GridLayout(2, 1, 0, -10));

		// 체크아웃 글자
		JLabel dayl2 = new JLabel("Check OUT");
		dayl2.setForeground(new Color(0, 0, 0));
		dayl2.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		dayl2.setHorizontalAlignment(JLabel.CENTER);
		date2.add(dayl2);
		// 체크아웃 캘린더
		model2 = new UtilDateModel();
		JDatePanelImpl datePanel2 = new JDatePanelImpl(model2);
		datePicker2 = new JDatePickerImpl(datePanel2, new DateLabelFormatter());
		datePicker2.getJFormattedTextField().setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 15));
		datePicker2.setBackground(new Color(226, 222, 244));
		datePicker2.getJFormattedTextField().setBackground(new Color(207, 201, 237));
		date2.add(datePicker2);
		date2.setBounds(320, 30, 160, 70);	
		getContentPane().add(date2);
		datePicker2.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		String cKi = datePicker.getJFormattedTextField().getText();
		String cKo = datePicker2.getJFormattedTextField().getText();

		try {
			difference = extracted(cKi, cKo);
		} catch (ParseException e1) {
			System.out.println("날짜선택 오류!");
			e1.printStackTrace();
		}

		System.out.println(difference);

		if (cKi != "" && cKo != "") {

			lblNewLabel_7.setVisible(true);
			lblNewLabel.setText("￦"+ String.valueOf(difference * 70000));
			lblNewLabel_2.setText(String.valueOf(difference) + "일");
			lblNewLabel_2.setVisible(true);
			lblNewLabel.setVisible(true);

			lblNewLabel_7_1.setVisible(true);
			lblNewLabel_1.setText("￦"+ String.valueOf(difference * 100000));
			lblNewLabel_3.setText(String.valueOf(difference) + "일");
			lblNewLabel_3.setVisible(true);
			lblNewLabel_1.setVisible(true);

			lblNewLabel_7_1_1.setVisible(true);
			lblNewLabel_1_1.setText("￦"+ String.valueOf(difference * 100000));
			lblNewLabel_4.setText(String.valueOf(difference) + "일");
			lblNewLabel_4.setVisible(true);
			lblNewLabel_1_1.setVisible(true);

			lblNewLabel_7_1_1_1.setVisible(true);
			lblNewLabel_1_2.setText("￦"+ String.valueOf(difference * 200000));
			lblNewLabel_5.setText(String.valueOf(difference) + "일");
			lblNewLabel_5.setVisible(true);
			lblNewLabel_1_2.setVisible(true);

			if (difference <= 0) {
				JOptionPane.showMessageDialog(null, "날짜를 다시 선택해주세요.");
			}
		}

		if (obj == btnNewButton) {
			new ReservationConfirm(cKi, cKo, sin, "싱글룸", id, difference);
		} else if (obj == btnNewButton_2) {
			new ReservationConfirm(cKi, cKo, dob, "더블룸", id, difference);
		} else if (obj == btnNewButton_3) {
			new ReservationConfirm(cKi, cKo, twn, "트윈룸", id, difference);
		} else if (obj == btnNewButton_4) {
			new ReservationConfirm(cKi, cKo, swt, "스위트룸", id, difference);
		}

	}

	private long extracted(String cKi, String cKo) throws ParseException {
		// 날짜 차이에 따른 숙박비 계산
		Date format1 = new SimpleDateFormat("yyyy-MM-dd").parse(cKo);
		Date format2 = new SimpleDateFormat("yyyy-MM-dd").parse(cKi);

		long diffSec = (format1.getTime() - format2.getTime()) / 1000; // 초 차이
		long diffMin = (format1.getTime() - format2.getTime()) / 60000; // 분 차이
		long diffHor = (format1.getTime() - format2.getTime()) / 3600000; // 시 차이
		long diffDays = diffSec / (24 * 60 * 60); // 일자수 차이

		return diffDays + 1;
	}

}
