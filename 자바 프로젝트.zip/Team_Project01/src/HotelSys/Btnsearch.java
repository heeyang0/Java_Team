package HotelSys;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Btnsearch extends JFrame {
	private JTable table;
	private JTextField textField;
	private JComboBox comboBox;
	public String column;
	private String text;
	private String ha;// 예약확정에 값 넣는곳

	static java.sql.Statement stmt;

	// 예약조회에서 씀
	public Btnsearch(JTable table, String text, String column, int i) { // 컬럼 이름, 값(text)를 받아오는거 (마지막i는 생성자 갯수가 밑에꺼랑 달라야
																		// 선언 가능해서 걍 넣은거임)
		this.column = column;
		this.table = table;
		this.text = text;
	}

	public void searchRC() {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		try {
			DB.init();
			String sql = "SELECT * FROM hotel WHERE " + column + " LIKE '%" + text + "%'";
			ResultSet rs = DB.getResultSet(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int cols = metaData.getColumnCount();
			String[] colName = new String[cols];

			for (int i = 0; i < colName.length; i++) {
				colName[i] = metaData.getColumnName(i + 1);
			}
			model.setColumnIdentifiers(colName);

			while (rs.next()) {
				Vector<Object> vec = new Vector<>();
				for (int i = 1; i <= cols; i++) {
					vec.add(rs.getObject(i));
				}
				model.addRow(vec);
			}
			if (model.getRowCount() == 0) {
				JOptionPane.showMessageDialog(this, "검색 결과가 없습니다.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
			}

			rs.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();

		}
	}

	// 관리자모드에서 씀
	public Btnsearch(JTable table, JTextField textfield, JComboBox comboBox) {
		this.table = table;
		this.textField = textfield;
		this.comboBox = comboBox;
	}

	public void search() {
		String columnName = comboBox.getSelectedItem().toString(); // 선택한 컬럼명 가져오기
		String searchText = textField.getText(); // 검색 텍스트 가져오기

		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0); // 테이블 초기화

		try {
			DB.init();
			String sql = "SELECT * FROM hotel WHERE " + columnName + " LIKE '%" + searchText + "%'";
			ResultSet rs = DB.getResultSet(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int cols = metaData.getColumnCount();
			String[] colName = new String[cols];

			for (int i = 0; i < colName.length; i++) {
				colName[i] = metaData.getColumnName(i + 1);
			}
			model.setColumnIdentifiers(colName);

			while (rs.next()) {
				Vector<Object> vec = new Vector<>();
				for (int i = 1; i <= cols; i++) {
					vec.add(rs.getObject(i));
				}
				model.addRow(vec);
			}
			if (model.getRowCount() == 0) {
				JOptionPane.showMessageDialog(this, "검색 결과가 없습니다.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
			}

			rs.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();

		}
	}

}